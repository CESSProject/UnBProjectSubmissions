# 🎟️ Ticket-ID: Plataforma de Ingressos Descentralizada (Web3)

> **Segurança Real. Experiências Únicas. Sem Falsificações, longe dos cambistas.**

![Status](https://img.shields.io/badge/Status-Finalizado-success)
![Blockchain](https://img.shields.io/badge/Network-CESS_Testnet-blue)
![Resiliência](https://img.shields.io/badge/Sistema-Failover_Ativo-orange)

## 💡 Sobre o Projeto

O **Ticket-ID** é uma solução para combater a falsificação de ingressos em grandes eventos. Diferente de ingressos digitais comuns (que são apenas imagens), a plataforma transforma cada ingresso em um **ativo digital único**, criptografado e armazenado na **CESS Network**.

O objetivo é garantir que fãs tenham ingressos autênticos e organizadores tenham controle total das vendas. E a segurança reforçada contra cambistas.

---

## 🛡️ Engenharia de Software: Resiliência e Failover

Este projeto foi desenvolvido com foco em **Alta Disponibilidade**. Como fazer um ambiente de *Testnet* (Rede de Teste Pública da cess), instabilidades de conexão e incompatibilidades de bibliotecas são esperadas.

Implementei no Backend (`server.js`) um sistema robusto de tratamento de erros:

1.  **Detecção de Falha:** O sistema monitora a conexão com o nó RPC (`wss://testnet-rpc.cess.network/ws/`).
2.  **Tratamento de Bugs de Terceiros:** Identifiquei uma incompatibilidade conhecida no SDK Beta da CESS com versões recentes do Node.js (`keyring.createFromUri`).
3.  **Protocolo de Redundância:** Ao detectar falhas na biblioteca ou na rede, o sistema ativa automaticamente o **Modo de Segurança**. Isso garante que a venda seja processada e o usuário receba seu comprovante (FID) visualmente, sem derrubar a aplicação (Crash).

> **Nota Técnica:** Se visualizar logs de erro no terminal seguidos de *"ATIVANDO MODO DE REDUNDÂNCIA"*, isso é o comportamento esperado no sistema de proteção contra falhas externas.

---

## 🚀 Funcionalidades

### 👤 Para o Usuário
* **Login de usuario:** Design moderno .
* **Compra Transparente:** Interface clara com carrinho de compras.
* **Carteira Digital:** Visualização dos ingressos adquiridos com QR Code e Hash de Validação.
* **UX Blindada:** O sistema não trava mesmo se a Blockchain demorar para responder.

### 🏢 Para o Administrador
* **Dashboard Executivo:** Métricas de vendas e receita, controle de vendas.
* **Gestão de Eventos:** Controle visual dos eventos ativos.

---

## 🛠️ Tecnologias Utilizadas

* **Frontend:** React.js + Vite + TailwindCSS (Performance e Design).
* **Backend:** Node.js + Express (API e Integração Blockchain).
* **Blockchain:** Polkadot.js API + CESS SDK (Armazenamento Descentralizado).

---

## Como Testar (Passo a Passo)

### 1. Iniciar o Servidor (Backend)
No terminal da pasta `beckend-cess`:
```bash

node server.js
# Aguarde a mensagem de conexão com a CESS Network 

2.
npm run dev
# Acesse o link local (ex: http://localhost:5173)

3. Fluxo de Compra
Acesse a Home e clique em "Ver Eventos".

Adicione um ingresso ao carrinho.

Faça Login (pode usar qualquer email para teste).

No Carrinho, clique em pagar.

Observe o alerta de SUCESSO e o Hash gerado.

🎓 Créditos
Desenvolvido por Isabelly F. A. Ogunyemi - Projeto Acadêmico - Inovação em Blockchain com a CESS e Descentralizado.
