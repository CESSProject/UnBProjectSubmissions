/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      container: {
        center: true, // <--- ISSO É O QUE CENTRALIZA TUDO
        padding: '2rem', // Dá um respiro nas bordas
      },
    },
  },
  plugins: [],
}